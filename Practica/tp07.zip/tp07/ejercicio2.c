
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define max 12
#define TAMA 50

struct 
{
    char nombre[TAMA], apellido[TAMA];
    int DNI;

}typedef coordinador;

struct 
{
    char destinoV[TAMA];
    int fechaS[max];
    int fechaR[max];
    int precioV;
}typedef destino;

struct 
{
    int *numerohabitR;
    int canthabit;
}typedef hotel;

struct 
{
    
}typedef agencia;


int main()
{
    srand(time(NULL));


    return 0;
}
