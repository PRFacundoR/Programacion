#include <stdio.h>
#include <ctype.h>
#include <string.h>
#define cant 30

int main()
{
    int may=0,min=0,num=0,longitud=8;
    char pass[cant];
    char passOk[cant];
    
    printf("ingrese su nueva contrasenia");
    fflush(stdin);
    scanf("%s",pass);

     int longitudActual = strlen(pass);
     printf("%d",longitudActual);

    for (int i = 0; i < longitudActual; i++)
    {
        if (isupper(pass[i]))
        {
            may=1;
        }
        
        if (islower(pass[i]))
        {
            min=1;
        }
        if (isdigit(pass[i]))
        {
            num=1;
        }

        if (longitudActual>= longitud)
        {
            printf("la longitud es correcta");
        }else
        {
            printf("longitud erronea");
        }
        
    }
           


     if (longitudActual>=longitud && may==1 && min==1 && num==1)
        {   
            printf("contrasenia correcta, reingrese la contrasenia para validar:\n");
            fflush(stdin);
            scanf("%c",&passOk[cant]);
            if (strcmp(pass, passOk)==0)
            {
                printf("las contrasenias son iguales");
            }
            

        }
    
    
    
       
    

    return 0;
}
