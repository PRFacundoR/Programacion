#include <stdio.h>
#include <string.h>

int main()
{
    char pass[30];
    scanf("%s",pass);
    printf("%d",strlen(pass));
    return 0;
}
