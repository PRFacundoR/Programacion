#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void mezclarCadenas(char *cad1, char *cad2, int pos );
#define TAMA 50
int main()
{
    char frase1[TAMA],frase2[TAMA],*cad1,*cad2;
    int pos;

    printf("Ingrese una palabra: \n");
    gets(frase1);
    cad1=malloc(TAMA*sizeof(char));
    cad1=frase1;

    printf("\nIngrese otra palabra: \n");
    gets(frase2);
    cad2=malloc(TAMA*sizeof(char));
    cad2=frase2;

    printf("ingrese la posicion:");
    scanf("%d", &pos);




mezclarCadenas(*cad1, *cad2, pos );



free(cad1);
free(cad2);

    return 0;
}

void mezclarCadenas(char *cad1, char *cad2, int pos ){
    cad1[pos]=cad2[0];

for (int i = 0; i < TAMA && cad2[i] != '\0'; i++)
{
    if (isalpha(cad2[i]))
    {
         cad1[pos]+=cad2[i];
    }
    pos++;
   
}
    printf("La frase concatenada es: %s", cad1);
}