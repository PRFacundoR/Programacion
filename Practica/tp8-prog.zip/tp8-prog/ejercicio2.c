#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100


struct 
{
    char sucursal[MAX];
    int dni;
    char nombre[MAX];
    int *listaCuBanc;
}typedef Cliente;

struct 
{
    int cbu;
    int tipoC;
    int saldoA;

}typedef cuentaBan;

struct 
{

    Cliente *cliente;
    cuentaBan *Cuentas;

} typedef Banco;


int main(){

    int cantCli=4;
    Banco *banco=(Banco*)malloc(cantCli*sizeof(Banco));

    banco[0]=(Banco){ (Cliente*)malloc(cantCli*sizeof(Cliente)), (cuentaBan*)malloc(cantCli*sizeof(cuentaBan)) }
    

    return 0;
}